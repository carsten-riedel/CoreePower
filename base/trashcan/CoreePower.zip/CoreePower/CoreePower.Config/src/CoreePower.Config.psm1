<#
    CoreePower.Config root module
#>

Import-Module -Name "CoreePower.Lib" -DisableNameChecking

. "$PSScriptRoot\CoreePower.Config.EnviromentVariable.ps1"
