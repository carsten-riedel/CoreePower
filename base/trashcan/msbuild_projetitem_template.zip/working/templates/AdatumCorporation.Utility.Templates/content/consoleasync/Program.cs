﻿// See https://aka.ms/new-console-template for more information
await Console.Out.WriteAsync("Hello World with C#");
